# Apple Retail Customer Care Analytics — Synthetic Portfolio Dataset

## Important
This is a fictional, synthetic portfolio dataset created for learning and demonstration. It is NOT Apple internal data, does not contain real customer information, and does not represent Apple's actual service targets or operating performance.

## Files
- `contact_interactions_raw.csv`: 22,180 rows (22,000 generated contacts plus 180 intentional duplicate rows). Main fact table.
- `agents.csv`: 150 synthetic agents and team attributes.
- `service_targets.csv`: illustrative channel-level response, resolution, FCR and CSAT targets.
- `monthly_staffing.csv`: illustrative monthly staffing capacity by region.

## Suggested Tableau Prep workflow
1. Connect to `contact_interactions_raw.csv`.
2. Profile fields and inspect nulls, duplicate `contact_id` values, negative durations, and inconsistent labels.
3. Standardize `channel` values (Phone, Chat, Email, Messaging) and `region` values (Americas, EMEIA, APAC).
4. Standardize country capitalization and trim whitespace.
5. Decide how to handle null `issue_category` values (e.g., `Unknown`).
6. Filter invalid negative durations; do not silently convert them to valid values.
7. Remove duplicate records using `contact_id` as the business key.
8. Join `agents.csv` on `agent_id`; join `service_targets.csv` on cleaned `channel`.
9. Output a cleaned `.hyper` extract or cleaned CSV for Tableau Desktop.

## Suggested calculated fields in Tableau Desktop
- Response SLA Met: `IF [first_response_seconds] <= [response_sla_seconds] THEN 1 ELSE 0 END`
- Resolution Hours: `[resolution_minutes] / 60`
- Resolution SLA Met: `IF [Resolution Hours] <= [resolution_sla_hours] THEN 1 ELSE 0 END`
- Contact Volume: `COUNTD([contact_id])`
- FCR %: `AVG([first_contact_resolution_flag])`
- Repeat Contact %: `AVG([repeat_contact_7d_flag])`
- Escalation %: `AVG([escalation_flag])`
- Average Handle Time (mins): `AVG([handle_seconds]) / 60`
- CSAT: `AVG([csat_score])` (exclude null survey scores naturally)

## Recommended dashboards
1. Executive Overview: contact volume, response SLA %, resolution SLA %, FCR %, CSAT, trend by month.
2. Regional & Channel Performance: region/channel heatmap, response time distribution, volume mix.
3. Agent & Team Performance: handled contacts, AHT, FCR, escalations; use fair context and avoid simplistic agent rankings.
4. Customer Experience: CSAT by issue/product/channel, repeat contacts, escalation drivers.

## Data dictionary highlights
- `first_response_seconds`: elapsed time to first response.
- `resolution_minutes`: elapsed time from contact creation to resolution.
- `handle_seconds`: active handling time.
- `transfer_count`: number of transfers between teams/agents.
- `first_contact_resolution_flag`: 1 if resolved on first contact, else 0.
- `repeat_contact_7d_flag`: 1 if customer contacted again within 7 days for the same issue, else 0.
- `survey_response_flag`: 1 if a survey response was received, else 0.
- `csat_score`: synthetic 1–5 satisfaction score; null when no survey response.
- `sla_target_seconds`: illustrative raw response target; use `service_targets.csv` as the target dimension in the Prep workflow.

All targets and results are invented for portfolio practice.
